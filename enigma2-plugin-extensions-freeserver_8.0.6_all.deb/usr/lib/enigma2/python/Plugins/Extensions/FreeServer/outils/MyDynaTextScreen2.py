#!/usr/bin/python
# -*- coding: UTF-8 -*-

from Plugins.Plugin import PluginDescriptor
from os import path as chmod
from shutil import move
from Screens.Screen import Screen
from datetime import date, datetime
from Components.Label import Label
from Screens.MessageBox import MessageBox
from Screens.Standby import *
from Components.Console import Console
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from Components.MediaPlayer import *
from enigma import *
from Components.Pixmap import Pixmap  
from Tools.Directories import *
from Components.GUIComponent import *
from Components.config import *
from time import *
import requests , re, time, os, sys, time, datetime
from Components.Sources.List import List

from Plugins.Extensions.FreeServer.outils.compat import PY3
from Plugins.Extensions.FreeServer.outils.CronTimers import *
from Plugins.Extensions.FreeServer.outils.LiseScreencccam import *
from Plugins.Extensions.FreeServer.outils.LiseScreencccam2 import * 
from Plugins.Extensions.FreeServer.outils.Console2 import *
from Plugins.Extensions.FreeServer.outils.Console33 import *
from Plugins.Extensions.FreeServer.outils.Input import *
from Plugins.Extensions.FreeServer.outils.MyShPrombt import *
from Plugins.Extensions.FreeServer.outils.Showinfo import *

session = None

###################################################################################################### 
s = requests.Session()
#https://www.logitheque.com/wp-content/uploads/sites/4/2020/09/how-set-up-iptv-smarters-pro-1024x576.jpg
######################################################################################################
LINKFILE1= '/tmp/ip'
LINKFILE2= '/tmp/ip2'
WGET='wget --no-check-certificate'
plugin_path = '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/fonts'
skin_path = '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/Skin/'
p_path = '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer'   
from enigma import addFont
try:
    addFont('%s/bpmono.ttf' % plugin_path, 'bpmo', 100, 1)
    
except Exception as ex:
    print(ex)

def DreamOS():
    if os.path.exists('/var/lib/dpkg/status'):
        return DreamOS

def getDesktopSize():
    s = getDesktop(0).size()
    return (s.width(), s.height())

def isHD():
    desktopSize = getDesktopSize()
    return desktopSize[0] == 1280
    
def connected_to_internet():   
    try:
        _ = requests.get('https://github.com', timeout=3)
        return True
    except :
        return False
        
#########################################################################################################
class MyDynaTextScreen2(Screen):
#### Edit By RAED
        if not isHD():
            if DreamOS():
            	skin = """
                      <screen position="0,0" size="1920,1080" title="Schedule to football matchs this week" backgroundColor="#16000000" flags="wfNoBorder">             
                      <widget source="Title" render="Label" position="12,7" size="600,32" font="Play;28" backgroundColor="#16000000" foregroundColor="#FFE375" valign="center" halign="center" zPosition="2"/>
                      <eLabel text="Move Up/Down or Left/Right to move list/page" position="600,7" size="680,32" font="Play;28" foregroundColor="#FC0000" backgroundColor="#16000000" zPosition="2"/>           
                      <widget name="myMenu" position="17,52" size="1865,1014" foregroundColor="#FEFEFE" transparent="1" zPosition="2"/>
                      <!--ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/Deco/SLIDE_03.jpg" alphatest="blend" transparent="1" /-->
                      </screen>"""
            else:
             	skin = """
                      <screen position="0,0" size="1916,1080" title="Schedule to football matchs this week" backgroundColor="#16000000" flags="wfNoBorder">             
                      <widget source="Title" render="Label" position="12,7" size="600,32" font="Play;28" backgroundColor="#16000000" foregroundColor="#FFE375" valign="center" halign="center" zPosition="2"/>
                      <eLabel text="Move Up/Down or Left/Right to move list/page" position="600,7" size="680,32" font="Play;28" foregroundColor="#FC0000" backgroundColor="#16000000" zPosition="2"/>           
                      <widget name="myMenu" position="25,52" size="1865,1014" font="Play;35" itemHeight="40" foregroundColor="#FEFEFE" transparent="1" zPosition="2"/>
                      <!--ePixmap position="0,0" size="1916,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/Deco/SLIDE_03.jpg" alphatest="blend" transparent="1" /-->
                      </screen>"""
        else:
                skin = """
                      <screen position="0,0" size="1280,720" title="Schedule to football matchs this week" backgroundColor="#16000000" flags="wfNoBorder">              
                      <widget source="Title" render="Label" position="12,7" size="600,32" font="Play;28" backgroundColor="#16000000" foregroundColor="#FFE375" valign="center" halign="center" zPosition="2"/>
                      <eLabel text="Move Up/Down or Left/Right to move list/page" position="600,7" size="680,32" font="Play;28" foregroundColor="#FC0000" backgroundColor="#16000000" zPosition="2"/>           
                      <widget name="myMenu" position="12,51" size="735,662" foregroundColor="#FEFEFE" transparent="1" zPosition="2"/>
                      <ePixmap position="0,0" size="1280,720" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/Deco/SLIDE_03.jpg" alphatest="blend" transparent="1" />
                      </screen>"""
        
        def __init__(self, session, finishedCallback = None, picPath = None, args = 0):
                self.session = session
                Screen.__init__(self, session)
                self.finishedCallback = finishedCallback
                self.setTitle("List of VPN server avilable")
                self.wget = "wget --no-check-certificate"
                list = []
                if config.plugins.FreeServerminoo.lang.value == "EN":
                        list.append(("Qahira", "com_1"))                         
                        list.append(("KSA", "com_2"))
                        list.append(("Algeria", "com_3"))  
                        list.append(("Morocco", "com_4"))
                        list.append(("EAU", "com_5")) 
                        list.append(("San Francisco", "com_6"))
                        list.append(("Nour Ala Nour", "com_7"))             
                        list.append(("Washington", "com_8"))
                        list.append(("Live 1", "com_9"))          
                        list.append(("Live 2", "com_10"))                        
                        list.append(("Live 3", "com_11"))
                        list.append(("Live 4", "com_12"))
                        list.append(("Live 5", "com_13"))                
                        list.append(("Ashams", "com_14"))
                elif config.plugins.FreeServerminoo.lang.value == "AR":
                        list.append(("القاهرة", "com_1"))                         
                        list.append(("السعودية", "com_2"))
                        list.append(("الجزائر", "com_3"))  
                        list.append(("المغرب", "com_4"))
                        list.append(("EAU", "com_5")) 
                        list.append(("النشرة الإسلامية", "com_6"))
                        list.append(("نور على نور", "com_7"))             
                        list.append(("واشنطن", "com_8"))
                        list.append(("مباشر", "com_9"))          
                        list.append(("مباشر", "com_10"))                        
                        list.append(("مباشر", "com_11"))
                        list.append(("مباشر", "com_12"))
                        list.append(("مباشر", "com_13"))                
                        list.append(("أشمس", "com_14"))
                elif config.plugins.FreeServerminoo.lang.value == "FR":
                        list.append(("Caire", "com_1"))                         
                        list.append(("Arabie Saoudite", "com_2"))
                        list.append(("Algérie", "com_3"))  
                        list.append(("Maroc", "com_4"))
                        list.append(("EAU", "com_5")) 
                        list.append(("San Francisco", "com_6"))
                        list.append(("Nour Ala Nour", "com_7"))             
                        list.append(("Washington", "com_8"))
                        list.append(("Live 1", "com_9"))          
                        list.append(("Live 2", "com_10"))                        
                        list.append(("Live 3", "com_11"))
                        list.append(("Live 4", "com_12"))
                        list.append(("Live 5", "com_13"))                
                        list.append(("Ashams", "com_14"))
                else:
                        list.append(("Qahira", "com_1"))                         
                        list.append(("KSA", "com_2"))
                        list.append(("Algeria", "com_3"))  
                        list.append(("Morocco", "com_4"))
                        list.append(("EAU", "com_5")) 
                        list.append(("San Francisco", "com_6"))
                        list.append(("Nour Ala Nour", "com_7"))             
                        list.append(("Washington", "com_8"))
                        list.append(("Live 1", "com_9"))          
                        list.append(("Live 2", "com_10"))                        
                        list.append(("Live 3", "com_11"))
                        list.append(("Live 4", "com_12"))
                        list.append(("Live 5", "com_13"))                
                        list.append(("Ashams", "com_14"))
                list.append((_("Exit"), "exit"))
                Screen.__init__(self, session)
                #self["myYellowBtn"] = Label(_("restart"))
                #self["myBlueBtn"] = Label(_("Preview"))
                self.cmdlist = []
                self.onChangedEntry = []
                self.initialservice = session.nav.getCurrentlyPlayingServiceReference()         
                self["myMenu"] = MenuList(list)
                self['setupActions'] = ActionMap(['SetupActions', 'ColorActions', 'DirectionActions'], 
                {
                        #'yellow': self.goto,
                        #'blue': self.gotoa,
                        'red': self.close,
                        'ok': self.go,
                        'cancel': self.close
                }, -1)
                self.go               
                self.onChangedEntry = []
                self.timer_list = []
                self.processed_timers = [] 
                self.timer = eTimer()
                self.initialservice = session.nav.getCurrentlyPlayingServiceReference()
                self.updateTimer = eTimer()
                self.timer.start(2000, True)
                self.timer = eTimer()
                self.timer.start(2, 1)
                self.onLayoutFinish.append(self.layoutFinished)
                self.Tilawa
### Edit By RAED To DreamOS & Fix update notification restart warrning
                try:
                       self.timer.callback.append(self.update)
                except:
                       self.timer_conn = self.timer.timeout.connect(self.update)


        def layoutFinished(self):
                self.setTitle(" ")


        def Tilawa(self):

            from enigma import eServiceReference
            from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
            url = "http://n06.radiojar.com/8s5u5tpdtwzuv"
            #url = 'http://ample-09.radiojar.com/8s5u5tpdtwzuv'
            #url = 'http://178.33.178.204:9322/index.html'
            #url = 'https://ia601507.us.archive.org/22/items/PremierLeague_201812/Premier_League.mp3'
            ref = eServiceReference(4097, 0, url)
            ref.setName(Version_1)
            self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)

       
        def backToIntialService(self, ret = None):
            self.session.nav.stopService()
            self.session.nav.playService(self.initialservice)
            self.fast()

        def fast(self):   
            self.timer.stop()
            #self.session.openWithCallback(self.close, ALAJREStream6, ref)
            #self.session.close(ALAJREStream5)
             
        def disappear(self):
            self.Tilawa()
                           
### End EDit
        def go(self):
                if config.plugins.FreeServerminoo.lang.value == "EN":
                	Version_1 = 'Plese Wait whIle is being updated... Plese be patient...'
                elif config.plugins.FreeServerminoo.lang.value == "AR":
                	Version_1 = u'... يرجى الانتظار بينما يتم تحديث وحدة التحكم الإلكترونية الخاصة بك ... يرجى التحلي بالصبر'
                elif config.plugins.FreeServerminoo.lang.value == "FR":
                	Version_1 = 'Veuillez patienter pendant la mise à jour... Veuillez patienter...'
                else:
                	Version_1 = 'Plese Wait whIle is being updated... Plese be patient...'
                returnValue = self["myMenu"].l.getCurrentSelection()[1]
                if returnValue != None:         
                        if returnValue =="com_1":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://n06.radiojar.com/8s5u5tpdtwzuv"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_2":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://stream.radiojar.com/4wqre23fytzuv"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_3":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://webradio.tda.dz/Coran_64K.mp3"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_4":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://92.222.103.13:8005/;stream.nsv"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_5":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://zayedquran.gov.ae/stream.php"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)                        
                        elif returnValue =="com_6":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://edge.mixlr.com/channel/liqju"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)                        
                        elif returnValue =="com_7":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://edge.mixlr.com/channel/eterm"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)   
                        elif returnValue =="com_8":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://66.45.232.131:9994/;stream.nsv"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)  
                        elif returnValue =="com_9":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://66.45.232.131:9994/;stream.nsv"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)  
                        elif returnValue =="com_10":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://206.72.199.179:9992/;stream.nsv"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)  
                        elif returnValue =="com_11":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://www.quran-radio.org:8080/;stream.nsv"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)  
                        elif returnValue =="com_12":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://live.mp3quran.net:9960/"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_13":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://listen.radioislam.co.za:8080/radioislam.mp3"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)  
                        elif returnValue =="com_14":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://tvs.jagobd.com/radio.php?u=al-quran-radio.stream&vw=780&vh=90"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        else:
                                print("\n[MyShPrombt] cancel\n")
                                self.close(None)
                                                                  
        def prombt(self, com):                
            scripts = "/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/"
            os.chmod(scripts, 755)
            self.session.open(Console3,_("Executing: %s") % (com), ["%s" % com])
        def cancel(self):
            self.close(None)
