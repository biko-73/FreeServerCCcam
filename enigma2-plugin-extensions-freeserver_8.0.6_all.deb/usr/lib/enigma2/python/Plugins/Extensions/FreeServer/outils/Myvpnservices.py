# -*- coding: UTF-8 -*-
from __future__ import print_function

from Plugins.Plugin import PluginDescriptor
from os import path as os_path, remove, unlink, rename, chmod, access, X_OK
from shutil import move
from Screens.Screen import Screen
from datetime import date, datetime
from Components.Label import Label
from Components.Sources.StaticText import StaticText
from enigma import eTimer, eConsoleAppContainer
from Screens.MessageBox import MessageBox
from Screens.Standby import TryQuitMainloop
from Components.Console import Console
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from Components.MediaPlayer import *
from enigma import *
from Screens.MessageBox import MessageBox
from Components.Pixmap import Pixmap  
from Tools.Directories import fileExists, pathExists
from Components.GUIComponent import *
from Screens.ServiceInfo import *
from Components.config import *
from enigma import eServiceReference
from Tools.Directories import fileExists
from time import *
import requests , json, re,string,time
from enigma import eTimer, getDesktop
from enigma import *
import os, sys, re
import shutil
import urllib 
import base64
#session = None
#data_xml = 'aHR0cHM6Ly9pYTYwMDcwMi51cy5hcmNoaXZlLm9yZy8yNi9pdGVtcy9kcmVhbW9zYXQvY2Ftc3RhcnQwLnR4dA=='
#xml_path = base64.b64decode(data_xml)
#version = '7710'    
#currversion = '7710'   
###################################################################################################### 
s = requests.Session()
#https://www.logitheque.com/wp-content/uploads/sites/4/2020/09/how-set-up-iptv-smarters-pro-1024x576.jpg
######################################################################################################
LINKFILE1= '/tmp/ip'
LINKFILE2= '/tmp/ip2'
WGET='wget --no-check-certificate'
plugin_path = '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/fonts'
skin_path = '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/Skin/'
p_path = '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer'   
from enigma import addFont
try:
    addFont('%s/bpmono.ttf' % plugin_path, 'bpmo', 100, 1)
    
except Exception as ex:
    print(ex)

def DreamOS():
    if os.path.exists('/var/lib/dpkg/status'):
        return DreamOS

def getDesktopSize():
    s = getDesktop(0).size()
    return (s.width(), s.height())

def isHD():
    desktopSize = getDesktopSize()
    return desktopSize[0] == 1280
    
def connected_to_internet():   
    try:
        _ = requests.get('https://github.com', timeout=3)
        return True
    except :
        return False
        
#########################################################################################################
class Myvpnservices(Screen):
#### Edit By RAED
        if not isHD():
            skin = """
                      <screen position="0,0" size="1916,1080" title="Schedule to football matchs this week" backgroundColor="#16000000" flags="wfNoBorder">             
                      <widget source="Title" render="Label" position="12,7" size="600,32" font="Play;28" backgroundColor="#16000000" foregroundColor="#FFE375" valign="center" halign="center" zPosition="2"/>
                      <eLabel text="Move Up/Down or Left/Right to move list/page" position="600,7" size="680,32" font="Play;28" foregroundColor="#FC0000" backgroundColor="#16000000" zPosition="2"/>           
                      <widget name="myMenu" position="17,52" size="754,1014" foregroundColor="#FEFEFE" transparent="1" zPosition="2"/>
                      <ePixmap position="0,0" size="1916,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/Deco/SLIDE_02.jpg" alphatest="blend" transparent="1" />
                      </screen>"""
        else:
                skin = """
                      <screen position="0,0" size="1280,720" title="Schedule to football matchs this week" backgroundColor="#16000000" flags="wfNoBorder">              
                      <widget source="Title" render="Label" position="12,7" size="600,32" font="Play;28" backgroundColor="#16000000" foregroundColor="#FFE375" valign="center" halign="center" zPosition="2"/>
                      <eLabel text="Move Up/Down or Left/Right to move list/page" position="600,7" size="680,32" font="Play;28" foregroundColor="#FC0000" backgroundColor="#16000000" zPosition="2"/>           
                      <widget name="myMenu" position="12,51" size="735,662" foregroundColor="#FEFEFE" transparent="1" zPosition="2"/>
                      <ePixmap position="0,0" size="1280,720" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/Deco/SLIDE_02.jpg" alphatest="blend" transparent="1" />
                      </screen>"""
        
        def __init__(self, session, finishedCallback = None, picPath = None, args = 0):
                self.session = session
                Screen.__init__(self, session)
                self.finishedCallback = finishedCallback
                self.setTitle("List of VPN server avilable")
                self.wget = "wget --no-check-certificate"
                list = [] 
                list.append(("        Download Cert. Files", "com_01"))                         
                list.append(("        QUEBEC 910", "com_1"))
                list.append(("        MONTREAL 694", "com_2"))  
                list.append(("        BEAUHAMOIS 123", "com_3"))
                list.append(("        CANADA 121", "com_4")) 
                list.append(("        VIRGINIA 240", "com_5"))
                list.append(("        NEW YORK 184", "com_6"))             
                list.append(("        NUREMBURG 851", "com_7"))
                list.append(("        MISSOURI 473", "com_8"))          
                list.append(("        EUROPE 230", "com_9"))
                list.append(("        ATLANTA 118", "com_10"))
                list.append(("        NEW JERSEY 120", "com_11"))
                list.append(("        SEATTLE 521", "com_12"))  
                list.append(("        CHICAGO 155", "com_13"))
                list.append(("        DALLAS 938", "com_14"))
                list.append(("        LONDON 103", "com_15"))                         
                list.append(("        PARIS 221", "com_16"))            
                list.append(("        LOS ANGELES 691", "com_17"))
                list.append(("                          ", "com_*****"))
                list.append(("        MIAMI 149", "com_18")) 
                list.append(("        TORONTO 160", "com_19"))                                  
                list.append(("        CHICAGO 132+", "com_20"))
                list.append(("        Sydney", "com_21"))
                list.append(("        Download Openvpn Config File tcp_80", "com_02"))
                list.append(("        Sydney, Australia", "com_22"))    
                list.append(("        Brussels, Belgium", "com_23"))    
                list.append(("        Sofia, Bulgaria", "com_24"))      
                list.append(("        Sao Paulo, Brazil", "com_25"))    
                list.append(("        Toronto, Canada", "com_26"))      
                list.append(("        Montreal, Canada", "com_27"))     
                list.append(("        Vancouver, Canada", "com_28"))    
                list.append(("        Zurich, Switzerland", "com_29"))  
                list.append(("        Prague, Czech Republic", "com_30"))       
                list.append(("        Frankfurt, Germany", "com_31"))   
                list.append(("        Dusseldorf, Germany", "com_32"))  
                list.append(("        Seville, Spain", "com_33"))       
                list.append(("        Barcelona, Spain", "com_34"))     
                list.append(("        Helsinki, Finland", "com_35"))    
                list.append(("        Paris, France", "com_36"))        
                list.append(("        London, United Kingdom", "com_37"))       
                list.append(("        London 2, United Kingdom", "com_38"))     
                list.append(("        London 3, United Kingdom", "com_39"))     
                list.append(("        Thessaloniki, Greece", "com_40"))         
                list.append(("        Hong Kong, Hong Kong", "com_41"))         
                list.append(("        Jakarta 5, Indonesia", "com_42"))         
                list.append(("        Jakarta 6, Indonesia", "com_43"))         
                list.append(("        Dublin, Ireland", "com_44"))      
                list.append(("        Tel Aviv, Israel", "com_45"))     
                list.append(("        Mumbai, India", "com_46"))        
                list.append(("        Palermo, Italy", "com_47"))       
                list.append(("        Tokyo, Japan", "com_48"))         
                list.append(("        Tokyo 2, Japan", "com_49"))       
                list.append(("        Tokyo 6, Japan", "com_50"))       
                list.append(("        Rotterdam, Netherlands", "com_51"))       
                list.append(("        Amsterdam, Netherlands", "com_52"))       
                list.append(("        Manila, Philippines", "com_53"))  
                list.append(("        Warsaw, Poland", "com_54"))       
                list.append(("        St Petersburg, Russian Federation", "com_55"))    
                list.append(("        Moscow, Russian Federation", "com_56"))   
                list.append(("        Stockholm, Sweden", "com_57"))    
                list.append(("        Singapore 2, Singapore", "com_58"))       
                list.append(("        Singapore, Singapore", "com_59"))         
                list.append(("        Ljubljana, Slovenia", "com_60"))  
                list.append(("        Bangkok, Thailand", "com_61"))    
                list.append(("        Bursa, Turkey", "com_62"))        
                list.append(("        Kiev, Ukraine", "com_63"))        
                list.append(("        Miami, United States", "com_64"))         
                list.append(("        Los Angeles, United States", "com_65"))   
                list.append(("        New York City, United States", "com_66"))         
                list.append(("        Miami 2, United States", "com_67"))       
                list.append(("        Johannesburg 2, South Africa", "com_68"))         
                list.append(("        Johannesburg, South Africa", "com_69"))
                list.append(("        Download Openvpn Config File udp_123", "com_03"))
                list.append(("        Sydney, Australia", "com_70"))    
                list.append(("        Brussels, Belgium", "com_71"))    
                list.append(("        Sofia, Bulgaria", "com_72"))      
                list.append(("        Sao Paulo, Brazil", "com_73"))    
                list.append(("        Toronto, Canada", "com_74"))      
                list.append(("        Montreal, Canada", "com_75"))     
                list.append(("        Vancouver, Canada", "com_76"))    
                list.append(("        Zurich, Switzerland", "com_77"))  
                list.append(("        Prague, Czech Republic", "com_78"))       
                list.append(("        Frankfurt, Germany", "com_79"))   
                list.append(("        Dusseldorf, Germany", "com_80"))  
                list.append(("        Seville, Spain", "com_81"))       
                list.append(("        Barcelona, Spain", "com_82"))     
                list.append(("        Helsinki, Finland", "com_83"))    
                list.append(("        Paris, France", "com_84"))        
                list.append(("        London, United Kingdom", "com_85"))       
                list.append(("        London 2, United Kingdom", "com_86"))     
                list.append(("        London 3, United Kingdom", "com_87"))     
                list.append(("        Thessaloniki, Greece", "com_88"))         
                list.append(("        Hong Kong, Hong Kong", "com_89"))         
                list.append(("        Jakarta 5, Indonesia", "com_90"))         
                list.append(("        Jakarta 6, Indonesia", "com_91"))         
                list.append(("        Dublin, Ireland", "com_92"))      
                list.append(("        Tel Aviv, Israel", "com_93"))     
                list.append(("        Mumbai, India", "com_94"))        
                list.append(("        Palermo, Italy", "com_95"))       
                list.append(("        Tokyo, Japan", "com_96"))         
                list.append(("        Tokyo 2, Japan", "com_97"))       
                list.append(("        Tokyo 6, Japan", "com_98"))       
                list.append(("        Rotterdam, Netherlands", "com_99"))       
                list.append(("        Amsterdam, Netherlands", "com_100"))      
                list.append(("        Manila, Philippines", "com_101"))         
                list.append(("        Warsaw, Poland", "com_102"))      
                list.append(("        St Petersburg, Russian Federation", "com_103"))   
                list.append(("        Moscow, Russian Federation", "com_104"))  
                list.append(("        Stockholm, Sweden", "com_105"))   
                list.append(("        Singapore 2, Singapore", "com_106"))      
                list.append(("        Singapore, Singapore", "com_107"))        
                list.append(("        Ljubljana, Slovenia", "com_108"))         
                list.append(("        Bangkok, Thailand", "com_109"))   
                list.append(("        Bursa, Turkey", "com_110"))       
                list.append(("        Kiev, Ukraine", "com_111"))       
                list.append(("        Miami, United States", "com_112"))        
                list.append(("        Los Angeles, United States", "com_113"))  
                list.append(("        New York City, United States", "com_114"))        
                list.append(("        Miami 2, United States", "com_115"))      
                list.append(("        Johannesburg 2, South Africa", "com_116"))        
                list.append(("        Johannesburg, South Africa", "com_117"))          
                list.append(("        Find My Ip", "com_118"))
                list.append(("        VPN_Stop", "com_119"))
                list.append(("        VPN Start", "com_120"))
                list.append(("        VPN Auto Start-up", "com_121"))
                list.append((_("        Exit"), "exit"))
                Screen.__init__(self, session)
                self["key_red"] = Label(_("Cancel"))
                self["key_green"] = Label(_("Clean"))
                #self["myYellowBtn"] = Label(_("restart"))
                #self["myBlueBtn"] = Label(_("Preview"))
                self.cmdlist = []
                self.onChangedEntry = []
                self.initialservice = session.nav.getCurrentlyPlayingServiceReference()         
                self["myMenu"] = MenuList(list)
                self['setupActions'] = ActionMap(['SetupActions', 'ColorActions', 'DirectionActions'], 
                {
                        'green': self.Clean,
                        #'yellow': self.goto,
                        #'blue': self.gotoa,
                        'red': self.close,
                        'ok': self.go,
                        'cancel': self.close
                }, -1)
                self.timer = eTimer()
                self.timer.start(2, 1)
                self.onLayoutFinish.append(self.layoutFinished)
### Edit By RAED To DreamOS & Fix update notification restart warrning
                try:
                       self.timer.callback.append(self.update)
                except:
                       self.timer_conn = self.timer.timeout.connect(self.update)


        def layoutFinished(self):
                self.setTitle(" ")

        def update(self):
                try:
                    fp = urllib.urlopen(xml_path)
                    count = 0
                    self.labeltext = ''
                    s1 = fp.readline()
                    s2 = fp.readline()
                    s3 = fp.readline()
                    s1 = s1.strip()
                    s2 = s2.strip()
                    s3 = s3.strip()
                    self.link = s2
                    self.version = s1
                    self.info = s3
                    fp.close()
                    cstr = s1 + ' ' + s2
                    if s1 <= currversion:
                        return
                        print('[No Update Avilable]')
                    else:  
                        self.session.openWithCallback(self.install, MessageBox, _('New update available.\n\nDo you want ot install now.'), MessageBox.TYPE_YESNO)
                        print('[New Update Avilable]')
                except:
                    return '[New Update Avilable]'

        def install(self, *retval):
            os.system("%s https://ia600702.us.archive.org/26/items/dreamosat/freecc4.sh -qO - | /bin/sh" % self.wget)
            self.session.openWithCallback(self.restartenigma, MessageBox, _('** Nedd Restart Enigma2 To Load New Update ?!! **'), MessageBox.TYPE_YESNO, timeout=10)


               
### End EDit
        def go(self):
                from Plugins.Extensions.FreeServer.outils.Console3 import Console3
                returnValue = self["myMenu"].l.getCurrentSelection()[1]
                if returnValue != None:         
                        if returnValue =="com_0":
                                cmdlist = []
                                cmdlist.append("%s -qO - '" % self.wget + "'")
                                cmdlist.append("%s https://ia801406.us.archive.org/25/items/iptvworld-24/IPTVWORLDVPN.sh -qO - | /bin/sh" % self.wget)
                                self.session.open(Console3, title='Free VPN', cmdlist=cmdlist, finishedCallback=None)
                        elif returnValue =="com_1":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg_conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc//etc/client_conf1', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  QUEBEC 910'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_2":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg_conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc//etc/client_conf2', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  MONTREAL 694'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_3":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg_conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc//etc/client_conf3', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  BEAUHAMOIS 123'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_4":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg_conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc//etc/client_conf4', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  CANADA 121'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_5":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg_conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc//etc/client_conf5', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  VIRGINIA 240'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_6":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg_conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc//etc/client_conf6', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  NEW YORK 184'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return                                                
                        elif returnValue =="com_7":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg_conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc//etc/client_conf7', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  NUREMBURG 851'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return 
                        elif returnValue =="com_8":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg_conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc//etc/client_conf8', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  MISSOURI 473'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_9":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg_conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc//etc/client_conf9', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  EUROPE 230'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_10":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg_conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc//etc/client_conf10', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  ATLANTA 118'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_11":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg_conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc//etc/client_conf11', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  NEW JERSEY 120'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_12":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg_conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc//etc/client_conf12', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  SEATTLE 521'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_13":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg_conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc//etc/client_conf13', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  CHICAGO 155'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_14":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg_conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc//etc/client_conf14', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  DALLAS 938'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_15":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg_conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc//etc/client_conf15', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  LONDON 103'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_16":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg_conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc//etc/client_conf16', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  PARIS 221'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_17":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg_conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc//etc/client_conf17', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  LOS ANGELES 691'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_18":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg_conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc//etc/client_conf18', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  MIAMI 149'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_19":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg_conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc//etc/client_conf19', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  TORONTO 160'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_20":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg_conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc//etc/client_conf20', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  CHICAGO 132+'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_21":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg_conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc//etc/client_conf21', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Sydney'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_02":
                                cmdlist = []
                                cmdlist.append("%s -qO - '" % self.wget + "'")
                                cmdlist.append("%s https://ia801406.us.archive.org/25/items/iptvworld-24/IPTVWORLDVPN2.sh -qO - | /bin/sh" % self.wget)
                                self.session.open(Console3, title='Free VPN', cmdlist=cmdlist, finishedCallback=None)
                        elif returnValue =="com_22":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf1', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Sydney, Australia'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_23":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf2', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Brussels, Belgium'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return              
                        elif returnValue =="com_24":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf3', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Sofia, Bulgaria'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return                      
                        elif returnValue =="com_25":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf4', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Sao Paulo, Brazil'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return              
                        elif returnValue =="com_26":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf5', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Toronto, Canada'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_27":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf6', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Montreal, Canada'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return              
                        elif returnValue =="com_28":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf7', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Vancouver, Canada'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return              
                        elif returnValue =="com_29":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf8', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Zurich, Switzerland'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return              
                        elif returnValue =="com_30":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf9', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Prague, Czech Republic'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return              
                        elif returnValue =="com_31":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf10', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Frankfurt, Germany'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return              
                        elif returnValue =="com_32":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf11', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Dusseldorf, Germany'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_33":                            
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf12', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Seville, Spain'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_34":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf13', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Barcelona, Spain'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_35":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf14', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Helsinki, Finland'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_36":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf15', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Paris, France'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return              
                        elif returnValue =="com_37":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf16', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  London, United Kingdom'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return                      
                        elif returnValue =="com_38":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf17', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  London 2, United Kingdom'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return                      
                        elif returnValue =="com_39":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf18', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  London 3, United Kingdom'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_40":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf19', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Thessaloniki, Greece'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_41":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf20', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Hong Kong, Hong Kong'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_42":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf21', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Jakarta 5, Indonesia'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_43":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf22', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Jakarta 6, Indonesia'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_44":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf23', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Dublin, Ireland'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_45":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf24', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Tel Aviv'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_46":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf25', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Mumbai, India'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_47":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf26', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Palermo, Italy'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_48":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf27', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Tokyo, Japan'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return  
                        elif returnValue =="com_49":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf28', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Tokyo 2, Japan'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return                      
                        elif returnValue =="com_50":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf29', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Tokyo 6, Japan'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return              
                        elif returnValue =="com_51":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf30', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Rotterdam, Netherlands'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_52":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf31', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Amsterdam, Netherlands'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_53":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf32', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Manila, Philippines'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_54":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf33', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Warsaw, Poland'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_55":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf34', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  St Petersburg'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return              
                        elif returnValue =="com_56":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf35', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Moscow, Russian Federation'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_57":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf36', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Stockholm, Sweden'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_58":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf37', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Singapore 2, Singapore'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return                      
                        elif returnValue =="com_59":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf38', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Singapore, Singapore'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_60":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf39', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Ljubljana, Slovenia'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_61":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf40', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Bangkok, Thailand'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_62":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf41', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Bursa, Turkey'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_63":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf42', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Kiev, Ukraine'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_64":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf43', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Miami, United States'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_65":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf44', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Los Angeles, United States'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_66":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf46', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  New York City, United States'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_67":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf47', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Miami 2, United States'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_68":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf48', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Johannesburg 2, South Africa'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_69":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg__conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client__conf49', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Johannesburg, South Africa'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_03":
                                cmdlist = []
                                cmdlist.append("%s -qO - '" % self.wget + "'")
                                cmdlist.append("%s https://ia801406.us.archive.org/25/items/iptvworld-24/IPTVWORLDVPN3.sh -qO - | /bin/sh" % self.wget)
                                self.session.open(Console3, title='Free VPN', cmdlist=cmdlist, finishedCallback=None)
                        elif returnValue =="com_70":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf1', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Sydney, Australia'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_71":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf2', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Brussels, Belgium'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_72":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf3', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Sofia, Bulgaria'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_73":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf4', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Sao Paulo, Brazil'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_74":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf5', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Toronto, Canada'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_75":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf6', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Montreal, Canada'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_76":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf7', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Vancouver, Canada'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_77":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf8', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Zurich, Switzerland'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_78":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf9', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Prague, Czech Republic'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_79":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf10', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Frankfurt, Germany'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_80":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf11', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Dusseldorf, Germany'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_81":                            
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf12', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Seville, Spain'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_82":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf13', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Barcelona, Spain'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_83":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf14', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Helsinki, Finland'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_84":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf15', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Paris, France'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_85":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf16', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  London, United Kingdom'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_86":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf17', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  London 2, United Kingdom'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_87":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf18', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  London 3, United Kingdom'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_88":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf19', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Thessaloniki, Greece'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_89":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf20', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Hong Kong, Hong Kong'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_90":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf21', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Jakarta 5, Indonesia'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_91":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf22', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Jakarta 6, Indonesia'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_92":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf23', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Dublin, Ireland'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_93":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf24', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Tel Aviv, Israel'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_94":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf25', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Mumbai, India'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_95":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf26', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Palermo, Italy'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_96":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf27', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Tokyo, Japan'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_97":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf28', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Tokyo 2, Japan'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return              
                        elif returnValue =="com_98":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf29', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Tokyo 6, Japan'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return              
                        elif returnValue =="com_99":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf30', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Rotterdam, Netherlands'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_100":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf31', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Amsterdam, Netherlands'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_101":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf32', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Manila, Philippines'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_102":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf33', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Warsaw, Poland'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_103":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf34', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  St Petersburg'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_104":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf35', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Moscow, Russian Federation'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_105":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf36', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Stockholm, Sweden'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_106":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf37', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Singapore 2, Singapore'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_107":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf38', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Singapore, Singapore'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_108":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf39', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Ljubljana, Slovenia'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_109":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf40', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Bangkok, Thailand'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_110":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf41', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Bursa, Turkey'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_111":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf42', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Kiev, Ukraine'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_112":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf43', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Miami, United States'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_113":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf44', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Los Angeles, United States'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_114":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf45', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  New York City, United States'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_115":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf46', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Miami 2, United States'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_116":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf47', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Johannesburg 2, South Africa'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_117":
                            if connected_to_internet():
                               os.system('/etc/init.d/openvpn stop > /dev/null 2>&1')
                               os.system('rm -r %s > /dev/null 2>&1 && rm -f %s > /dev/null 2>&1' % (LINKFILE1, LINKFILE2))
                               os.system('rm -r -f /etc/openvpn; mkdir /etc/openvpn') 
                               shutil.copyfile('/etc/cfg.conf', '/etc/openvpn/cfg.conf')
                               shutil.copyfile('/etc/client.conf48', '/etc/openvpn/client.conf')
                               ip = urllib.urlopen("http://ip.42.pl/raw").read()
                               with open(LINKFILE1, "a") as f: f.write(ip)                                   
                               f = open(LINKFILE1, 'r')
                               for line in f.readlines():
                                   IP = line.strip('\n')
                                   os.system('/etc/init.d/openvpn start > /dev/null 2>&1')
                                   time.sleep(8)
                                   ip2 = urllib.urlopen("http://ip.42.pl/raw").read()
                                   with open(LINKFILE2, "a") as f: f.write(ip2)                                       
                                   f = open(LINKFILE2, 'r')
                                   for line in f.readlines():
                                       IP2 = line.strip('\n')
                                       if ip == ip2:
                                           self.session.open(MessageBox, _('VPN Not Working?...'), MessageBox.TYPE_INFO, timeout=5)
                                       else:
                                           self.session.open(MessageBox, _('Your Ip Address is :  ' + str(IP) + '\nYour New Ip Address is :  ' + str(IP2) + '\nYour Ip Location is :  Johannesburg, South Africa'), MessageBox.TYPE_INFO, timeout=10)
                            else:
                                self.session.open(MessageBox, _('Cannot connect (or server is down) !'), MessageBox.TYPE_INFO, timeout=5)
                            return
                        elif returnValue =="com_118":
                                cmdlist = []
                                cmdlist.append("%s -qO - '" % self.wget + "'")
                                cmdlist.append("%s https://ia800702.us.archive.org/26/items/dreamosat/find_myCurrent-ip.sh -qO - | /bin/sh" % self.wget)
                                self.session.open(Console3, title='Free VPN', cmdlist=cmdlist, finishedCallback=None)
                        elif returnValue =="com_119":
                                cmdlist = []
                                cmdlist.append("%s -qO - '" % self.wget + "'")
                                cmdlist.append("%s https://ia800702.us.archive.org/26/items/dreamosat/OpenVPN_STOP.sh -qO - | /bin/sh" % self.wget)
                                self.session.open(Console3, title='Free VPN', cmdlist=cmdlist, finishedCallback=None)
                        elif returnValue =="com_120":
                                cmdlist = []
                                cmdlist.append("%s -qO - '" % self.wget + "'")
                                cmdlist.append("%s https://ia800702.us.archive.org/26/items/dreamosat/OpenVPN_START.sh -qO - | /bin/sh" % self.wget)
                                self.session.open(Console3, title='Free VPN', cmdlist=cmdlist, finishedCallback=None)
                        elif returnValue =="com_121":
                                cmdlist = []
                                cmdlist.append("%s -qO - '" % self.wget + "'")
                                cmdlist.append("%s https://ia800702.us.archive.org/26/items/dreamosat/OpenVPN_AUTO.sh -qO - | /bin/sh" % self.wget)
                                self.session.open(Console3, title='Free VPN', cmdlist=cmdlist, finishedCallback=None)

                        else:
                                print("\n[MyShPrombt] cancel\n")
                                self.close(None)

        def Update(self):
            Update = "afile"
            afile = open('/tmp/monfichier.txt', 'w')
            self.session.openWithCallback(self.restartenigma, MessageBox, _('Free Server V_' + str(Update) + '\nRestart Enigma2 To Load New Settings?'), MessageBox.TYPE_YESNO)


        #def goto(self):
            #self.session.openWithCallback(self.restartenigma, MessageBox, _('Restart Enigma2 To Load New Update?'), MessageBox.TYPE_YESNO, timeout=20)

        def restartenigma(self, result):
            if result:
                self.session.open(TryQuitMainloop, 3)

        #def gotoa(self):
            #cmdlist = []
### EDit By RAED To DreamOS OE2.5/2.6
            #cmdlist.append("%s -qO - '" % self.wget + "'")
            #cmdlist.append("%s https://ia903000.us.archive.org/30/items/FreeServerinfo/free4k.sh -qO - | /bin/sh" % self.wget)
            #self.session.open(Console3, title='Update links Bein Sport', cmdlist=cmdlist, finishedCallback=None)

        #def Clean(self):
            #tmp = os.system("echo $(ls -sh /tmp | grep 'total' | sed 's/total '//) > /tmp/volume")            
            #if os.path.exists('/tmp/volume'):
                #f = open('/tmp/volume', 'r')
                #for line in f.readlines():
                        #id = line.strip('\n')
               #os.system("rm -rf /tmp/*")
                #self.session.open.(self.restart, MessageBox, _('Job Finish.\n\n ' + (id) + ' tmp is clean.'), MessageBox.TYPE_YESNO)

                #retval = self.container.execute("echo $(df -h /tmp | tail -1 | awk '{print $2}') > /tmp/volume && echo Available:   $(df -h /tmp | tail -1 | awk '{print $2}') >> /tmp/volume && echo Use  echo $(df -h /tmp | tail -1 | awk '{print $4}' >> /tmp/volume")                

        def Clean(self):
            self.container = eConsoleAppContainer()
            retval = self.container.execute("echo $(df -h /tmp | tail -1 | awk '{print $2}') > /tmp/volume && echo $(df -h /tmp | tail -1 | awk '{print $3}') > /tmp/volume2 && echo $(df -h /tmp | tail -1 | awk '{print $4}') > /tmp/volume3 && echo $(df -h /tmp | tail -1 | awk '{print $5}') > /tmp/volume4")                
            if os.path.exists('/tmp/volume'):
               f = open('/tmp/volume', 'r')
               for line in f.readlines():
                   id = line.strip('\n')
            if os.path.exists('/tmp/volume2'):
               f = open('/tmp/volume2', 'r')
               for line in f.readlines():
                   id2 = line.strip('\n')
            if os.path.exists('/tmp/volume3'):
               f = open('/tmp/volume3', 'r')
               for line in f.readlines():
                   id3 = line.strip('\n')
            if os.path.exists('/tmp/volume4'):
               f = open('/tmp/volume4', 'r')
               for line in f.readlines():
                   id4 = line.strip('\n')
               self.session.openWithCallback(self.doclean, MessageBox, _('End of the task.\nDo you really want to Delete all temporary file storage in /tmp files ?\nSize: ' + (id) + '\nUsed ' + (id2) + '\nAvailable: ' + (id3) + '\nUsed% ' + (id4) + '\n'),  MessageBox.TYPE_YESNO)

        def doclean(self, answer=False):
            if answer:
                os.system("rm -rf /tmp/*")
            else:
                return  
                
        def AUTOUPD(self):
            cmdlist = []
            cmdlist.append("%s -qO - '" % self.wget + "'")
            cmdlist.append("%s https://ia903000.us.archive.org/30/items/FreeServerinfo/Auto_update_Freeiptv.sh -qO - | /bin/sh" % self.wget)
            self.session.open(Console3, title='AUTO Update links Bein Sport RMC', cmdlist=cmdlist, finishedCallback=None)
        def prombt(self, com):
            scripts = "/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/"
            os.chmod(scripts, 755)
            self.session.open(Console3,_("Executing: %s") % (com), ["%s" % com])
        def cancel(self):
            self.close(None)
