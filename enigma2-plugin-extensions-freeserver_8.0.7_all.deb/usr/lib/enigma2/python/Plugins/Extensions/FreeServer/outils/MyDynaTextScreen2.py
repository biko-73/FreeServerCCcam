#!/usr/bin/python
# -*- coding: UTF-8 -*-

from Plugins.Plugin import PluginDescriptor
from os import path as chmod
from shutil import move
from Screens.Screen import Screen
from datetime import date, datetime
from Components.Label import Label
from Screens.MessageBox import MessageBox
from Screens.Standby import *
from Components.Console import Console
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from Components.MediaPlayer import *
from enigma import *
from Components.Pixmap import Pixmap  
from Tools.Directories import *
from Components.GUIComponent import *
from Components.config import *
from time import *
import requests , re, time, os, sys, time, datetime
from Components.Sources.List import List

from Plugins.Extensions.FreeServer.outils.compat import PY3
from Plugins.Extensions.FreeServer.outils.CronTimers import *
from Plugins.Extensions.FreeServer.outils.LiseScreencccam import *
from Plugins.Extensions.FreeServer.outils.LiseScreencccam2 import * 
from Plugins.Extensions.FreeServer.outils.Console2 import *
from Plugins.Extensions.FreeServer.outils.Console33 import *
from Plugins.Extensions.FreeServer.outils.Input import *
from Plugins.Extensions.FreeServer.outils.MyShPrombt import *
from Plugins.Extensions.FreeServer.outils.Showinfo import *

session = None

###################################################################################################### 
s = requests.Session()
#https://www.logitheque.com/wp-content/uploads/sites/4/2020/09/how-set-up-iptv-smarters-pro-1024x576.jpg
######################################################################################################
LINKFILE1= '/tmp/ip'
LINKFILE2= '/tmp/ip2'
WGET='wget --no-check-certificate'
plugin_path = '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/fonts'
skin_path = '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/Skin/'
p_path = '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer'   
from enigma import addFont
try:
    addFont('%s/bpmono.ttf' % plugin_path, 'bpmo', 100, 1)
    
except Exception as ex:
    print(ex)

def DreamOS():
    if os.path.exists('/var/lib/dpkg/status'):
        return DreamOS

def getDesktopSize():
    s = getDesktop(0).size()
    return (s.width(), s.height())

def isHD():
    desktopSize = getDesktopSize()
    return desktopSize[0] == 1280
    
def connected_to_internet():   
    try:
        _ = requests.get('https://github.com', timeout=3)
        return True
    except :
        return False
        
#########################################################################################################
class MyDynaTextScreen2(Screen):
#### Edit By RAED
        if not isHD():
            if DreamOS():
            	skin = """
                      <screen position="0,0" size="1920,1080" title="Schedule to football matchs this week" backgroundColor="#16000000" flags="wfNoBorder">             
                      <widget source="Title" render="Label" position="12,7" size="600,32" font="Play;28" backgroundColor="#16000000" foregroundColor="#FFE375" valign="center" halign="center" zPosition="2"/>
                      <eLabel text="Move Up/Down or Left/Right to move list/page" position="600,7" size="680,32" font="Play;28" foregroundColor="#FC0000" backgroundColor="#16000000" zPosition="2"/>           
                      <widget name="myMenu" position="17,52" size="1865,1014" foregroundColor="#FEFEFE" transparent="1" zPosition="2"/>
                      <!--ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/Deco/SLIDE_03.jpg" alphatest="blend" transparent="1" /-->
                      </screen>"""
            else:
             	skin = """
                      <screen position="0,0" size="1916,1080" title="Schedule to football matchs this week" backgroundColor="#16000000" flags="wfNoBorder">             
                      <widget source="Title" render="Label" position="12,7" size="600,32" font="Play;28" backgroundColor="#16000000" foregroundColor="#FFE375" valign="center" halign="center" zPosition="2"/>
                      <eLabel text="Move Up/Down or Left/Right to move list/page" position="600,7" size="680,32" font="Play;28" foregroundColor="#FC0000" backgroundColor="#16000000" zPosition="2"/>           
                      <widget name="myMenu" position="25,52" size="1865,1014" font="Play;35" itemHeight="40" foregroundColor="#FEFEFE" transparent="1" zPosition="2"/>
                      <!--ePixmap position="0,0" size="1916,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/Deco/SLIDE_03.jpg" alphatest="blend" transparent="1" /-->
                      </screen>"""
        else:
                skin = """
                      <screen position="0,0" size="1280,720" title="Schedule to football matchs this week" backgroundColor="#16000000" flags="wfNoBorder">              
                      <widget source="Title" render="Label" position="12,7" size="600,32" font="Play;28" backgroundColor="#16000000" foregroundColor="#FFE375" valign="center" halign="center" zPosition="2"/>
                      <eLabel text="Move Up/Down or Left/Right to move list/page" position="600,7" size="680,32" font="Play;28" foregroundColor="#FC0000" backgroundColor="#16000000" zPosition="2"/>           
                      <widget name="myMenu" position="12,51" size="735,662" foregroundColor="#FEFEFE" transparent="1" zPosition="2"/>
                      <ePixmap position="0,0" size="1280,720" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/Deco/SLIDE_03.jpg" alphatest="blend" transparent="1" />
                      </screen>"""
        
        def __init__(self, session, finishedCallback = None, picPath = None, args = 0):
                self.session = session
                Screen.__init__(self, session)
                self.finishedCallback = finishedCallback
                self.setTitle("List of VPN server avilable")
                self.wget = "wget --no-check-certificate"
                list = []
                if config.plugins.FreeServerminoo.lang.value == "EN":
                        list.append(("Qahira", "com_1"))                         
                        list.append(("KSA", "com_2"))
                        list.append(("Algeria", "com_3"))  
                        list.append(("Morocco", "com_4"))
                        list.append(("EAU", "com_5")) 
                        list.append(("San Francisco", "com_6"))
                        list.append(("Nour Ala Nour", "com_7"))             
                        list.append(("Washington", "com_8"))
                        list.append(("Live 1", "com_9"))          
                        list.append(("Live 2", "com_10"))                        
                        list.append(("Live 3", "com_11"))
                        list.append(("Live 4", "com_12"))
                        list.append(("Live 5", "com_13"))                
                        list.append(("Ashams", "com_14"))
                        list.append(("Chaarawi", "com_15"))
                        list.append(("Maka", "com_16"))
                        list.append(("Ahl Al Quran", "com_17"))
                        list.append(("UK", "com_18"))
                        list.append(("Naplouse", "com_19"))
                        list.append(("Spain", "com_20"))
                        list.append(("Buzzislam", "com_21"))
                        list.append(("Australia", "com_22"))
                        list.append(("Dawn", "com_23"))                
                        list.append(("Crescent", "com_24"))
                        list.append(("Al Manshuroh", "com_25"))
                        list.append(("Rodja", "com_26"))
                        list.append(("Lebanon", "com_27"))
                        list.append(("Live 6", "com_28"))
                        list.append(("New York", "com_29"))
                        list.append(("San Francisco 2", "com_30"))
                        list.append(("San Francisco 3", "com_31"))
                        list.append(("Live 7", "com_32"))
                        list.append(("Verse 24", "com_33"))
                        list.append(("Nouvelle-Galles du Sud , Sydney", "com_34"))
                        list.append(("Kandahar", "com_35"))
                        list.append(("Beyrouth", "com_36"))
                        list.append(("Abou Dabi", "com_37"))
                        list.append(("Hanoi", "com_38")) 
                        list.append(("Sharjah", "com_39"))    
                        list.append(("Khartoum", "com_40"))
                        list.append(("Dusseldorf", "com_41"))
                        list.append(("San Francisco 4", "com_42"))
                        list.append(("Berlin", "com_43"))
                        list.append(("New Jersey", "com_44"))
                        list.append(("District de Columbia", "com_45"))
                        list.append(("Saint Gall", "com_46"))
                        list.append(("Bandung", "com_47"))
                        list.append(("Istanbul", "com_48"))
                        list.append(("Victoria", "com_49"))
                        list.append(("Ankara", "com_50"))
                        list.append(("Maka", "com_51"))
                        list.append(("Abidjan", "com_52"))
                        list.append(("Miraath's", "com_53"))
                        list.append(("Birmingham", "com_54"))
                        list.append(("Tirana", "com_55"))
                        list.append(("National Capital Region, Capitol", "com_56"))
                        list.append(("Adwaa", "com_57"))
                        list.append(("Adwaa 2", "com_58")) 
                        list.append(("San Francisco", "com_59"))
                        list.append(("Java occidental", "com_60"))             
                        list.append(("Tunis", "com_61"))
                        list.append(("Ankara", "com_62"))          
                        list.append(("Hayat", "com_63"))                        
                        list.append(("Paris", "com_64"))
                        list.append(("Kayseri", "com_65"))
                        list.append(("Manama", "com_66"))                
                        list.append(("Antalya", "com_67"))
                        list.append(("Dakar", "com_68"))
                        list.append(("Tripoli", "com_69"))
                        list.append(("Gaza", "com_70"))
                        list.append(("District de Columbia, Washington", "com_71"))
                        list.append(("Tripoli 2", "com_72"))
                        list.append(("Sirius", "com_73"))
                        list.append(("Alsiyada", "com_74"))
                        list.append(("Berlin", "com_75"))
                        list.append(("New Jersey, Union City", "com_76"))                
                        list.append(("Omdourman", "com_77"))
                        list.append(("Copenhague", "com_78"))
                        list.append(("Koweit", "com_79"))
                        list.append(("Kampala", "com_80"))
                        list.append(("Region metropolitaine de Santiago", "com_81"))
                        list.append(("Rio de Janeiro", "com_82"))
                        list.append(("Khartoum", "com_83"))
                        list.append(("Baburrohmah", "com_84"))
                        list.append(("Rabat", "com_85"))
                        list.append(("Beyrouth", "com_86"))
                        list.append(("Londres", "com_87"))
                        list.append(("Birmingham", "com_88"))
                        list.append(("Sydney", "com_89"))
                        list.append(("Sunnah", "com_90"))
                        list.append(("Amman", "com_91")) 
                        list.append(("Birlik", "com_92"))    
                        list.append(("District de Columbia, Washington", "com_93"))
                        list.append(("Cisjordanie", "com_94"))
                        list.append(("Manchester", "com_95"))
                        list.append(("Berlin", "com_96"))
                        list.append(("New Jersey", "com_97"))
                        list.append(("Jakarta", "com_98"))
                        list.append(("Sabeel Al Anbiyya", "com_99"))
                        list.append(("Eman City", "com_100"))
                elif config.plugins.FreeServerminoo.lang.value == "AR":
                        list.append(("القاهرة", "com_1"))                         
                        list.append(("السعودية", "com_2"))
                        list.append(("الجزائر", "com_3"))  
                        list.append(("المغرب", "com_4"))
                        list.append(("EAU", "com_5")) 
                        list.append(("النشرة الإسلامية", "com_6"))
                        list.append(("نور على نور", "com_7"))             
                        list.append(("واشنطن", "com_8"))
                        list.append(("مباشر", "com_9"))          
                        list.append(("مباشر", "com_10"))                        
                        list.append(("مباشر", "com_11"))
                        list.append(("مباشر", "com_12"))
                        list.append(("مباشر", "com_13"))                
                        list.append(("أشمس", "com_14"))
                        list.append(("Chaarawi", "com_15"))
                        list.append(("Maka", "com_16"))
                        list.append(("Ahl Al Quran", "com_17"))
                        list.append(("UK", "com_18"))
                        list.append(("Naplouse", "com_19"))
                        list.append(("Spain", "com_20"))
                        list.append(("Buzzislam", "com_21"))
                        list.append(("Australia", "com_22"))
                        list.append(("Dawn", "com_23"))                
                        list.append(("Crescent", "com_24"))
                        list.append(("Al Manshuroh", "com_25"))
                        list.append(("Rodja", "com_26"))
                        list.append(("Lebanon", "com_27"))
                        list.append(("Live 6", "com_28"))
                        list.append(("New York", "com_29"))
                        list.append(("San Francisco 2", "com_30"))
                        list.append(("San Francisco 3", "com_31"))
                        list.append(("Live 7", "com_32"))
                        list.append(("Verse 24", "com_33"))
                        list.append(("Nouvelle-Galles du Sud , Sydney", "com_34"))
                        list.append(("Kandahar", "com_35"))
                        list.append(("Beyrouth", "com_36"))
                        list.append(("Abou Dabi", "com_37"))
                        list.append(("Hanoi", "com_38")) 
                        list.append(("Sharjah", "com_39"))    
                        list.append(("Khartoum", "com_40"))
                        list.append(("Dsseldorf", "com_41"))
                        list.append(("San Francisco 4", "com_42"))
                        list.append(("Berlin", "com_43"))
                        list.append(("New Jersey", "com_44"))
                        list.append(("District de Columbia", "com_45"))
                        list.append(("Saint Gall", "com_46"))
                        list.append(("Bandung", "com_47"))
                        list.append(("Istanbul", "com_48"))
                        list.append(("Victoria", "com_49"))
                        list.append(("Ankara", "com_50"))
                        list.append(("Maka", "com_51"))
                        list.append(("Abidjan", "com_52"))
                        list.append(("Miraath's", "com_53"))
                        list.append(("Birmingham", "com_54"))
                        list.append(("Tirana", "com_55"))
                        list.append(("National Capital Region, Capitol", "com_56"))
                        list.append(("Adwaa", "com_57"))
                        list.append(("Adwaa 2", "com_58")) 
                        list.append(("San Francisco", "com_59"))
                        list.append(("Java occidental", "com_60"))             
                        list.append(("Tunis", "com_61"))
                        list.append(("Ankara", "com_62"))          
                        list.append(("Hayat", "com_63"))                        
                        list.append(("Paris", "com_64"))
                        list.append(("Kayseri", "com_65"))
                        list.append(("Manama", "com_66"))                
                        list.append(("Antalya", "com_67"))
                        list.append(("Dakar", "com_68"))
                        list.append(("Tripoli", "com_69"))
                        list.append(("Gaza", "com_70"))
                        list.append(("District de Columbia, Washington", "com_71"))
                        list.append(("Tripoli 2", "com_72"))
                        list.append(("Sirius", "com_73"))
                        list.append(("Alsiyada", "com_74"))
                        list.append(("Berlin", "com_75"))
                        list.append(("New Jersey, Union City", "com_76"))                
                        list.append(("Omdourman", "com_77"))
                        list.append(("Copenhague", "com_78"))
                        list.append(("Koweit", "com_79"))
                        list.append(("Kampala", "com_80"))
                        list.append(("Region metropolitaine de Santiago", "com_81"))
                        list.append(("Rio de Janeiro", "com_82"))
                        list.append(("Khartoum", "com_83"))
                        list.append(("Baburrohmah", "com_84"))
                        list.append(("Rabat", "com_85"))
                        list.append(("Beyrouth", "com_86"))
                        list.append(("Londres", "com_87"))
                        list.append(("Birmingham", "com_88"))
                        list.append(("Sydney", "com_89"))
                        list.append(("Sunnah", "com_90"))
                        list.append(("Amman", "com_91")) 
                        list.append(("Birlik", "com_92"))    
                        list.append(("District de Columbia, Washington", "com_93"))
                        list.append(("Cisjordanie", "com_94"))
                        list.append(("Manchester", "com_95"))
                        list.append(("Berlin", "com_96"))
                        list.append(("New Jersey", "com_97"))
                        list.append(("Jakarta", "com_98"))
                        list.append(("Sabeel Al Anbiyya", "com_99"))
                        list.append(("Eman City", "com_100"))
                elif config.plugins.FreeServerminoo.lang.value == "FR":
                        list.append(("Caire", "com_1"))                         
                        list.append(("Arabie Saoudite", "com_2"))
                        list.append(("Algérie", "com_3"))  
                        list.append(("Maroc", "com_4"))
                        list.append(("EAU", "com_5")) 
                        list.append(("San Francisco", "com_6"))
                        list.append(("Nour Ala Nour", "com_7"))             
                        list.append(("Washington", "com_8"))
                        list.append(("Live 1", "com_9"))          
                        list.append(("Live 2", "com_10"))                        
                        list.append(("Live 3", "com_11"))
                        list.append(("Live 4", "com_12"))
                        list.append(("Live 5", "com_13"))                
                        list.append(("Ashams", "com_14"))
                        list.append(("Chaarawi", "com_15"))
                        list.append(("Maka", "com_16"))
                        list.append(("Ahl Al Quran", "com_17"))
                        list.append(("UK", "com_18"))
                        list.append(("Naplouse", "com_19"))
                        list.append(("Spain", "com_20"))
                        list.append(("Buzzislam", "com_21"))
                        list.append(("Australia", "com_22"))
                        list.append(("Dawn", "com_23"))                
                        list.append(("Crescent", "com_24"))
                        list.append(("Al Manshuroh", "com_25"))
                        list.append(("Rodja", "com_26"))
                        list.append(("Lebanon", "com_27"))
                        list.append(("Live 6", "com_28"))
                        list.append(("New York", "com_29"))
                        list.append(("San Francisco 2", "com_30"))
                        list.append(("San Francisco 3", "com_31"))
                        list.append(("Live 7", "com_32"))
                        list.append(("Verse 24", "com_33"))
                        list.append(("Nouvelle-Galles du Sud , Sydney", "com_34"))
                        list.append(("Kandahar", "com_35"))
                        list.append(("Beyrouth", "com_36"))
                        list.append(("Abou Dabi", "com_37"))
                        list.append(("Hanoi", "com_38")) 
                        list.append(("Sharjah", "com_39"))    
                        list.append(("Khartoum", "com_40"))
                        list.append(("Dusseldorf", "com_41"))
                        list.append(("San Francisco 4", "com_42"))
                        list.append(("Berlin", "com_43"))
                        list.append(("New Jersey", "com_44"))
                        list.append(("District de Columbia", "com_45"))
                        list.append(("Saint Gall", "com_46"))
                        list.append(("Bandung", "com_47"))
                        list.append(("Istanbul", "com_48"))
                        list.append(("Victoria", "com_49"))
                        list.append(("Ankara", "com_50"))
                        list.append(("Maka", "com_51"))
                        list.append(("Abidjan", "com_52"))
                        list.append(("Miraath's", "com_53"))
                        list.append(("Birmingham", "com_54"))
                        list.append(("Tirana", "com_55"))
                        list.append(("National Capital Region, Capitol", "com_56"))
                        list.append(("Adwaa", "com_57"))
                        list.append(("Adwaa 2", "com_58")) 
                        list.append(("San Francisco", "com_59"))
                        list.append(("Java occidental", "com_60"))             
                        list.append(("Tunis", "com_61"))
                        list.append(("Ankara", "com_62"))          
                        list.append(("Hayat", "com_63"))                        
                        list.append(("Paris", "com_64"))
                        list.append(("Kayseri", "com_65"))
                        list.append(("Manama", "com_66"))                
                        list.append(("Antalya", "com_67"))
                        list.append(("Dakar", "com_68"))
                        list.append(("Tripoli", "com_69"))
                        list.append(("Gaza", "com_70"))
                        list.append(("District de Columbia, Washington", "com_71"))
                        list.append(("Tripoli 2", "com_72"))
                        list.append(("Sirius", "com_73"))
                        list.append(("Alsiyada", "com_74"))
                        list.append(("Berlin", "com_75"))
                        list.append(("New Jersey, Union City", "com_76"))                
                        list.append(("Omdourman", "com_77"))
                        list.append(("Copenhague", "com_78"))
                        list.append(("Koweit", "com_79"))
                        list.append(("Kampala", "com_80"))
                        list.append(("Region metropolitaine de Santiago", "com_81"))
                        list.append(("Rio de Janeiro", "com_82"))
                        list.append(("Khartoum", "com_83"))
                        list.append(("Baburrohmah", "com_84"))
                        list.append(("Rabat", "com_85"))
                        list.append(("Beyrouth", "com_86"))
                        list.append(("Londres", "com_87"))
                        list.append(("Birmingham", "com_88"))
                        list.append(("Sydney", "com_89"))
                        list.append(("Sunnah", "com_90"))
                        list.append(("Amman", "com_91")) 
                        list.append(("Birlik", "com_92"))    
                        list.append(("District de Columbia, Washington", "com_93"))
                        list.append(("Cisjordanie", "com_94"))
                        list.append(("Manchester", "com_95"))
                        list.append(("Berlin", "com_96"))
                        list.append(("New Jersey", "com_97"))
                        list.append(("Jakarta", "com_98"))
                        list.append(("Sabeel Al Anbiyya", "com_99"))
                        list.append(("Eman City", "com_100"))
                else:
                        list.append(("Qahira", "com_1"))                         
                        list.append(("KSA", "com_2"))
                        list.append(("Algeria", "com_3"))  
                        list.append(("Morocco", "com_4"))
                        list.append(("EAU", "com_5")) 
                        list.append(("San Francisco", "com_6"))
                        list.append(("Nour Ala Nour", "com_7"))             
                        list.append(("Washington", "com_8"))
                        list.append(("Live 1", "com_9"))          
                        list.append(("Live 2", "com_10"))                        
                        list.append(("Live 3", "com_11"))
                        list.append(("Live 4", "com_12"))
                        list.append(("Live 5", "com_13"))                
                        list.append(("Ashams", "com_14"))
                        list.append(("Chaarawi", "com_15"))
                        list.append(("Maka", "com_16"))
                        list.append(("Ahl Al Quran", "com_17"))
                        list.append(("UK", "com_18"))
                        list.append(("Naplouse", "com_19"))
                        list.append(("Spain", "com_20"))
                        list.append(("Buzzislam", "com_21"))
                        list.append(("Australia", "com_22"))
                        list.append(("Dawn", "com_23"))                
                        list.append(("Crescent", "com_24"))
                        list.append(("Al Manshuroh", "com_25"))
                        list.append(("Rodja", "com_26"))
                        list.append(("Lebanon", "com_27"))
                        list.append(("Live 6", "com_28"))
                        list.append(("New York", "com_29"))
                        list.append(("San Francisco 2", "com_30"))
                        list.append(("San Francisco 3", "com_31"))
                        list.append(("Live 7", "com_32"))
                        list.append(("Verse 24", "com_33"))
                        list.append(("Nouvelle-Galles du Sud , Sydney", "com_34"))
                        list.append(("Kandahar", "com_35"))
                        list.append(("Beyrouth", "com_36"))
                        list.append(("Abou Dabi", "com_37"))
                        list.append(("Hanoi", "com_38")) 
                        list.append(("Sharjah", "com_39"))    
                        list.append(("Khartoum", "com_40"))
                        list.append(("Dusseldorf", "com_41"))
                        list.append(("San Francisco 4", "com_42"))
                        list.append(("Berlin", "com_43"))
                        list.append(("New Jersey", "com_44"))
                        list.append(("District de Columbia", "com_45"))
                        list.append(("Saint Gall", "com_46"))
                        list.append(("Bandung", "com_47"))
                        list.append(("Istanbul", "com_48"))
                        list.append(("Victoria", "com_49"))
                        list.append(("Ankara", "com_50"))
                        list.append(("Maka", "com_51"))
                        list.append(("Abidjan", "com_52"))
                        list.append(("Miraath's", "com_53"))
                        list.append(("Birmingham", "com_54"))
                        list.append(("Tirana", "com_55"))
                        list.append(("National Capital Region, Capitol", "com_56"))
                        list.append(("Adwaa", "com_57"))
                        list.append(("Adwaa 2", "com_58")) 
                        list.append(("San Francisco", "com_59"))
                        list.append(("Java occidental", "com_60"))             
                        list.append(("Tunis", "com_61"))
                        list.append(("Ankara", "com_62"))          
                        list.append(("Hayat", "com_63"))                        
                        list.append(("Paris", "com_64"))
                        list.append(("Kayseri", "com_65"))
                        list.append(("Manama", "com_66"))                
                        list.append(("Antalya", "com_67"))
                        list.append(("Dakar", "com_68"))
                        list.append(("Tripoli", "com_69"))
                        list.append(("Gaza", "com_70"))
                        list.append(("District de Columbia, Washington", "com_71"))
                        list.append(("Tripoli 2", "com_72"))
                        list.append(("Sirius", "com_73"))
                        list.append(("Alsiyada", "com_74"))
                        list.append(("Berlin", "com_75"))
                        list.append(("New Jersey, Union City", "com_76"))                
                        list.append(("Omdourman", "com_77"))
                        list.append(("Copenhague", "com_78"))
                        list.append(("Koweit", "com_79"))
                        list.append(("Kampala", "com_80"))
                        list.append(("Region metropolitaine de Santiago", "com_81"))
                        list.append(("Rio de Janeiro", "com_82"))
                        list.append(("Khartoum", "com_83"))
                        list.append(("Baburrohmah", "com_84"))
                        list.append(("Rabat", "com_85"))
                        list.append(("Beyrouth", "com_86"))
                        list.append(("Londres", "com_87"))
                        list.append(("Birmingham", "com_88"))
                        list.append(("Sydney", "com_89"))
                        list.append(("Sunnah", "com_90"))
                        list.append(("Amman", "com_91")) 
                        list.append(("Birlik", "com_92"))    
                        list.append(("District de Columbia, Washington", "com_93"))
                        list.append(("Cisjordanie", "com_94"))
                        list.append(("Manchester", "com_95"))
                        list.append(("Berlin", "com_96"))
                        list.append(("New Jersey", "com_97"))
                        list.append(("Jakarta", "com_98"))
                        list.append(("Sabeel Al Anbiyya", "com_99"))
                        list.append(("Eman City", "com_100"))
                list.append((_("Exit"), "exit"))
                Screen.__init__(self, session)
                #self["myYellowBtn"] = Label(_("restart"))
                #self["myBlueBtn"] = Label(_("Preview"))
                self.cmdlist = []
                self.onChangedEntry = []
                self.initialservice = session.nav.getCurrentlyPlayingServiceReference()         
                self["myMenu"] = MenuList(list)
                self['setupActions'] = ActionMap(['SetupActions', 'ColorActions', 'DirectionActions'], 
                {
                        #'yellow': self.goto,
                        #'blue': self.gotoa,
                        'red': self.close,
                        'ok': self.go,
                        'cancel': self.close
                }, -1)
                self.go               
                self.onChangedEntry = []
                self.timer_list = []
                self.processed_timers = [] 
                self.timer = eTimer()
                self.initialservice = session.nav.getCurrentlyPlayingServiceReference()
                self.updateTimer = eTimer()
                self.timer.start(2000, True)
                self.timer = eTimer()
                self.timer.start(2, 1)
                self.onLayoutFinish.append(self.layoutFinished)
                self.Tilawa
### Edit By RAED To DreamOS & Fix update notification restart warrning
                try:
                       self.timer.callback.append(self.update)
                except:
                       self.timer_conn = self.timer.timeout.connect(self.update)


        def layoutFinished(self):
                self.setTitle(" ")


        def Tilawa(self):

            from enigma import eServiceReference
            from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
            url = "http://n06.radiojar.com/8s5u5tpdtwzuv"
            #url = 'http://ample-09.radiojar.com/8s5u5tpdtwzuv'
            #url = 'http://178.33.178.204:9322/index.html'
            #url = 'https://ia601507.us.archive.org/22/items/PremierLeague_201812/Premier_League.mp3'
            ref = eServiceReference(4097, 0, url)
            ref.setName(Version_1)
            self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)

       
        def backToIntialService(self, ret = None):
            self.session.nav.stopService()
            self.session.nav.playService(self.initialservice)
            self.fast()

        def fast(self):   
            self.timer.stop()
            #self.session.openWithCallback(self.close, ALAJREStream6, ref)
            #self.session.close(ALAJREStream5)
             
        def disappear(self):
            self.Tilawa()
                           
### End EDit
        def go(self):
                if config.plugins.FreeServerminoo.lang.value == "EN":
                	Version_1 = 'Plese Wait whIle is being updated... Plese be patient...'
                elif config.plugins.FreeServerminoo.lang.value == "AR":
                	Version_1 = u'... يرجى الانتظار بينما يتم تحديث وحدة التحكم الإلكترونية الخاصة بك ... يرجى التحلي بالصبر'
                elif config.plugins.FreeServerminoo.lang.value == "FR":
                	Version_1 = 'Veuillez patienter pendant la mise à jour... Veuillez patienter...'
                else:
                	Version_1 = 'Plese Wait whIle is being updated... Plese be patient...'
                returnValue = self["myMenu"].l.getCurrentSelection()[1]
                if returnValue != None:         
                        if returnValue =="com_1":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://n06.radiojar.com/8s5u5tpdtwzuv"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_2":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://stream.radiojar.com/4wqre23fytzuv"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_3":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://webradio.tda.dz/Coran_64K.mp3"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_4":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://92.222.103.13:8005/;stream.nsv"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_5":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://zayedquran.gov.ae/stream.php"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)                        
                        elif returnValue =="com_6":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://edge.mixlr.com/channel/liqju"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)                        
                        elif returnValue =="com_7":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://edge.mixlr.com/channel/eterm"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)   
                        elif returnValue =="com_8":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://66.45.232.131:9994/;stream.nsv"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)  
                        elif returnValue =="com_9":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://66.45.232.131:9994/;stream.nsv"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)  
                        elif returnValue =="com_10":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://206.72.199.179:9992/;stream.nsv"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)  
                        elif returnValue =="com_11":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://www.quran-radio.org:8080/;stream.nsv"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)  
                        elif returnValue =="com_12":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://live.mp3quran.net:9960/"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_13":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://listen.radioislam.co.za:8080/radioislam.mp3"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)  
                        elif returnValue =="com_14":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://tvs.jagobd.com/radio.php?u=al-quran-radio.stream&vw=780&vh=90"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_15":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://livstream.xyz:8010/;el-shaarawy.mp3"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_16":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://r7.tarat.com:8004/;"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_17":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://r7.tarat.com:8002/;"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_18":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://server03.quran.com.kw:7032/;"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_19":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://www.quran-radio.org:8002/;stream.nsv"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_20":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://66.45.232.134:9300/;"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_21":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://tunein.buzzislam.com/radio/8000/radio.mp3"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_22":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://www.2mfm.org.au:8000/live"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_23":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://radiodawn.radioca.st/stream"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_24":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://icecast.commedia.org.uk:8000/crescent.mp3"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_25":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://66.45.232.133:9998/;"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_26":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://radioislamindonesia.com/rodja.mp3"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_27":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://162.244.81.30:8224/;stream.mp3?src=1"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_28":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://104.167.2.55:8000/;"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_29":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://206.72.199.179:9992/;"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_30":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://edge.mixlr.com/channel/rwumx"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_31":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://104.7.66.64:8095/stream/1/"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_32":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://158.69.227.214/proxy/umfarooq?mp=/stream"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_33":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://149.28.52.216:3344/stream/1/"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                        elif returnValue =="com_34":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'")  
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://104.167.2.55:8000/;"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)  
                        elif returnValue =="com_35":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://aradio.aryanict.com:9332/;"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)       
                        elif returnValue =="com_36":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://149.28.52.216:3344/stream/1/"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_37":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://162.244.81.30:8224/;"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_38":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://www.qurantranslations.net/sound/English/AbdulBaset_AbdulSamad/002.mp3?type=.mp3/;stream.mp3"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_39":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://l3.itworkscdn.net/smcquranlive/quranradiolive/icecast.audio"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_40":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://alzainquran.radioca.st/stream"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_41":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://server4.streamserver24.com:21494/stream/1/"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_42":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://104.7.66.64:8088/stream/1/"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_43":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://66.45.232.133:9998/;stream.nsv"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_45":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://66.45.232.132:9996/;"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_46":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://149.28.52.216:3344/stream/1/"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_47":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://s1.wohooo.net:9018/;"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_47":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://svara-stream.radioddns.net:8000/bandung_mqfm_mp3"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_48":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://streamer3.rightclickitservices.com:9755/;"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_49":
                            if connected_to_internet():                                            
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://149.28.52.216:3344/stream/1/"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_50":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://yayin.dostfm.com:8920/;"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)                                     
                        elif returnValue =="com_51":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://andromeda.shoutca.st:8189/stream"                           
                               ref = eServiceReference(4097, 0, url)  
                        elif returnValue =="com_52":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://stream.zenolive.com/seb77kna90duv"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)
                        elif returnValue =="com_53":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://radio.al7eah.net/8010/stream"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)
                        elif returnValue =="com_54":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://live.canstream.co.uk:8000/unity.mp3"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)
                        elif returnValue =="com_55":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://rtvpendimi.com:8020/;stream.nsv"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)
                        elif returnValue =="com_56":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://tunzilla.com:443/http://109.169.23.124:9091/stream?type=.aac"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)
                        elif returnValue =="com_57":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://stream.zeno.fm/x4451xh0x1zuv"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_58":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://stream.zeno.fm/vrrtqsh0x1zuv"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)
                        elif returnValue =="com_59":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://149.28.52.216:3344/stream/1/"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                        elif returnValue =="com_60":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://void.idserverhost.com:8010/;"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)         
                               self.session.openWithCallback(self.backToIntialService, ALAJREStream5, ref)  
                        elif returnValue =="com_61":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://zitounafm.toutech.net/zitounalive"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)       
                        elif returnValue =="com_62":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://stream.radyogrup.com:4010/;"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_63":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://104.194.9.142:8302/live"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_64":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://francemaghreb2.ice.infomaniak.ch/francemaghreb2-high.mp3"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_65":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://yayin2.canliyayin.org:7082/;stream.nsv"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_66":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://mediati.me/radio/8010/radio.mp3"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_67":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://yayin2.canliyayin.org:8400/;stream.nsv"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_68":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://listen.senemultimedia.net:5526/;"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_69":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://162.244.80.52:6656/stream"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_70":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://live.alboraq.ps:8000/;stream.mp3"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_71":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://66.45.232.134:9300/;"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_72":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://162.244.80.118:5678/stream"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_73":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://s8.voscast.com:7112/;"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_74":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://tijaniyyah.asuscomm.com:8000/stream/9/"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_75":
                            if connected_to_internet():                                            
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://95.173.161.133:9394/;stream.nsv"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_76":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://206.72.199.180:9990/;"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)                                     
                        elif returnValue =="com_77":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://tijaniyyah.asuscomm.com:8000/stream/2/"                           
                               ref = eServiceReference(4097, 0, url)  
                        elif returnValue =="com_78":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://5.56.158.246:8000/stream"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)
                        elif returnValue =="com_79":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://server2.quraan.us:9814/;*.mp3"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)
                        elif returnValue =="com_80":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://s13.myradiostream.com:40212/;stream.nsv"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)
                        elif returnValue =="com_81":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://5.9.65.9:8031/live?1508938696879"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)
                        elif returnValue =="com_82":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://s3.voscast.com:8450/;"                            
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_83":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://tijaniyyah.asuscomm.com:8000/stream/4/"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_84":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://sv3.alhasmedia.com/radio/8270/radio"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_85":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://92.222.103.13:8005/;stream.nsv"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_86":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://162.244.81.30:8224/;"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_87":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://139.59.200.203:8000/radio.mp3"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_88":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://live.canstream.co.uk:8000/unity.mp3"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_89":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://islam2day.tv:9898/;"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_90":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://andromeda.shoutca.st:8189/stream"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_91":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://104.194.9.142:8302/live"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_92":
                            if connected_to_internet():                                            
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://yayin2.canliyayin.org:7082/;stream.nsv"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)   
                        elif returnValue =="com_93":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://66.45.232.131:9994/;"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)                                     
                        elif returnValue =="com_94":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://www.quran-radio.org:8080/;stream.mp3"                           
                               ref = eServiceReference(4097, 0, url)  
                        elif returnValue =="com_95":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://icecast.commedia.org.uk:8000/crescent.mp3"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)
                        elif returnValue =="com_96":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://radio.al7eah.net/8010/stream"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)
                        elif returnValue =="com_97":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://live.canstream.co.uk:8000/unity.mp3"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)
                        elif returnValue =="com_98":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://stream.zeno.fm/64bx3eq5cnruv"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)
                        elif returnValue =="com_99":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "https://radio.al7eah.net/8042/stream"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1)
                        elif returnValue =="com_100":
                            if connected_to_internet():
                               self.wget = "wget --no-check-certificate"
                               import sys,os  
                               os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/picturecimages.sh'") 
                               from enigma import eServiceReference
                               from Plugins.Extensions.FreeServer.outils.InfoBar import ALAJREStream5
                               url = "http://206.72.199.180:9990/;"                           
                               ref = eServiceReference(4097, 0, url)
                               ref.setName(Version_1) 
                        else:
                                print("\n[MyShPrombt] cancel\n")
                                self.close(None)
        def prombt(self, com):                
            scripts = "/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/"
            os.chmod(scripts, 755)
            self.session.open(Console3,_("Executing: %s") % (com), ["%s" % com])
        def cancel(self):
            self.close(None)
