# -*- coding: UTF-8 -*-
from __future__ import print_function

from Components.Pixmap import Pixmap
from Components.ActionMap import ActionMap
from Components.Input import Input
from Screens.InputBox import InputBox
from Screens.MessageBox import MessageBox
from Tools.Directories import fileExists
from Screens.Screen import Screen
import re
import sys,os
###########################################################################

class myInput(Screen):
    skin = """<screen position="100,120" size="856,556" title="Press Ok to Entre Password (Pass) and Press Ok" >
              <widget name="icon" render="Pixmap" pixmap="/tmp/myPic.png" zPosition="5" position="356,120" size="488,401" alphatest="blend" borderWidth="2" borderColor="white" backgroundColor="black" />
              </screen>"""
    def __init__(self, session, args = 0):
        self.session = session
        Screen.__init__(self, session)
        self["myActionMap"] = ActionMap(["SetupActions"],{"ok": self.myInput,"cancel": self.cancel,"1": self.convert}, -1)

### EDit By RAED To DreamOS OE2.5/2.6
        #if fileExists('/var/lib/dpkg/status'):
        #     self.wget = "/usr/bin/wget2 --no-check-certificate"
        #else:
        #     self.wget = "/usr/bin/wget"
        self.wget = "wget --no-check-certificate"
### End
        import sys,os  
        os.system("sh '/usr/lib/enigma2/python/Plugins/Extensions/FreeServer/scripts/pictureimage.sh'") 
        self['icon'] = Pixmap()
    def askForWord(self, word):
        if word is None:
            pass
        elif word == '':
            pass
        else:
            if fileExists('/tmp/freeservre77'):
                with open('/tmp/freeservre77', "a") as f: f.write(word)
                #self.wget = "wget --no-check-certificate"
                #os.system("%s https://ia600702.us.archive.org/26/items/dreamosat/cccam48h.sh -qO - | /bin/sh" % self.wget)
                #with open('/tmp/freeservre77', "a") as f: f.write(word)
                f = open('/tmp/freeservre77', 'r')
                for line in f.readlines():
                    id = line.strip('\n')
                    try:cfg_line='C: storesat.tk 1455 storesat {0}'.format(id)
                    except:pass
                    with open('/etc/CCcam.cfg', "a") as f: f.write("\n"+cfg_line)
                    self.convert
                    self.session.open(MessageBox,_('Your Free Cline CCcam is '+cfg_line+'\nActivated in: /etc/CCcam.cfg\n Press 1 to convert oscam and ncam server'), MessageBox.TYPE_INFO, timeout=5) 
            else:
                    self.session.open(MessageBox,_('File /tmp/freeservre76 Not Found'), MessageBox.TYPE_INFO, timeout=5)

    def convert(self):
        ncamfile="/etc/tuxbox/config/ncam.server"
        oscamfile="/etc/tuxbox/config/oscam.server"
        ccamfile="/etc/CCcam.cfg"
        ## We read the CCcam.cfg and convert it to oscam.server 
        r=open(oscamfile,'a')
        r=open(ncamfile,'a')
        r.close()
        for line in open(ccamfile,'r').readlines():
            lines = re.match(r'(.*)C: (.*?) (.*?) (.*?) (.*)',line)
            if lines:
             w=open(oscamfile,'a')
             w.write("\n")
             w.write("[reader]"+"\n")
             w.write("enable = 1"+"\n")
             w.write("label = "+ lines.group(2)+"\n")
             w.write("protocol = cccam"+"\n")         
             w.write("device = "+lines.group(2)+","+lines.group(3)+"\n")
             w.write("user = "+lines.group(4)+"\n")
             w.write("password = "+lines.group(5)+"\n")
             w.write("inactivitytimeout = 30"+"\n")
             w.write("disablecrccws_only_for = 098C:000000;09C4:000000"+"\n")
             w.write("cacheex_allow_request = 1"+"\n")
             w.write("cacheex_drop_csp = 1"+"\n")
             w.write("cacheex_drop_csp = 1"+"\n")
             w.write("dropbadcws = 1"+"\n")
             w.write("reconnecttimeout = 5"+"\n")
             w.write("group = 1"+"\n")
             w.write("emmcache = 1,3,2,0"+"\n")
             w.write("blockemm-unknown = 1"+"\n")
             w.write("blockemm-u = 1"+"\n")
             w.write("blockemm-s = 1"+"\n")
             w.write("blockemm-g = 1"+"\n")
             w.write("cccversion = 2.0.11"+"\n")
             w.write("ccckeepalive = 1"+"\n")
             w.close() 
        
        for line in open(ccamfile,'r').readlines():
            lines = re.match(r'(.*)C: (.*?) (.*?) (.*?) (.*)',line)
            if lines:
             w=open(ncamfile,'a')
             w.write("\n")
             w.write("[reader]"+"\n")
             w.write("enable = 1"+"\n")
             w.write("label = "+ lines.group(2)+"\n")
             w.write("protocol = cccam"+"\n")         
             w.write("device = "+lines.group(2)+","+lines.group(3)+"\n")
             w.write("user = "+lines.group(4)+"\n")
             w.write("password = "+lines.group(5)+"\n")
             w.write("inactivitytimeout = 30"+"\n")
             w.write("disablecrccws_only_for = 098C:000000;09C4:000000"+"\n")
             w.write("cacheex_allow_request = 1"+"\n")
             w.write("cacheex_drop_csp = 1"+"\n")
             w.write("cacheex_drop_csp = 1"+"\n")
             w.write("dropbadcws = 1"+"\n")
             w.write("reconnecttimeout = 5"+"\n")
             w.write("group = 1"+"\n")
             w.write("emmcache = 1,3,2,0"+"\n")
             w.write("blockemm-unknown = 1"+"\n")
             w.write("blockemm-u = 1"+"\n")
             w.write("blockemm-s = 1"+"\n")
             w.write("blockemm-g = 1"+"\n")
             w.write("cccversion = 2.0.11"+"\n")
             w.write("ccckeepalive = 1"+"\n")
             w.close() 


    def myInput(self):
        self.session.openWithCallback(self.askForWord, InputBox, title=_("Please Enter Password (Pass) and Press Ok"), text="", maxSize=False, type=Input.TEXT)        

    def cancel(self):
        self.close(self) 
#****************************************************************************** 


                              
